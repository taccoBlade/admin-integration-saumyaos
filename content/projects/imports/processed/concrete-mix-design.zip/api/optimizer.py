# Python optimizer for aggregate blending
import numpy as np
def optimize_blend(aggregates):
    return np.mean(aggregates)