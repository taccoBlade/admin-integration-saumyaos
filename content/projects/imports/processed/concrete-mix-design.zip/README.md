# Concrete Mix Design Dashboard

Interactive dashboard for concrete mix proportioning and verification according to IS 10262:2019.

## Overview
This system optimizes materials and proportions for concrete manufacturing. It automates calculations that traditionally required complex tables and manual charting, reducing calculation times to seconds while verifying compliance with safety limits.

## Technologies
- Next.js
- React
- TailwindCSS
- Python
- IS 10262:2019

## Key Outcomes
- Accelerated concrete mix proportioning calculations by 95%
- Developed automated safety tolerance validation interface
- Designed visual curves matching compaction and strength characteristics

## Lessons Learned
- Integrating legacy engineering design codes (IS 10262) into modern React validation states requires structured schemas.
- Visual feedback on aggregate grading curves greatly helps field technicians adjust mixes.
